package phase2;
import java.util.Date;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Operation {
	
	private Date operationDate;
	private Member member;
	private Item item;
	private OperationType type;
	
	/**
	 * @param operationDate
	 * @param member
	 * @param item
	 * @param type
	 */
	public Operation(Date operationDate, Member member, Item item, OperationType type) {
		super();
		this.operationDate = operationDate;
		this.member = member;
		this.item = item;
		this.type = type;
	}
	/**
	 * @return
	 */
	public Date getOperationDate() {
		return operationDate;
	}
	/**
	 * @param operationDate
	 */
	public void setOperationDate(Date operationDate) {
		this.operationDate = operationDate;
	}
	/**
	 * @return
	 */
	public Member getMember() {
		return member;
	}
	/**
	 * @param member
	 */
	public void setMember(Member member) {
		this.member = member;
	}
	/**
	 * @return
	 */
	public Item getItem() {
		return item;
	}
	/**
	 * @param item
	 */
	public void setItem(Item item) {
		this.item = item;
	}
	/**
	 * @return
	 */
	public OperationType getType() {
		return type;
	}
	/**
	 * @param type
	 */
	public void setType(OperationType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return String.format("Operation Date:%s\n Member:%s\n Item: %s\n OperationType: %s", operationDate, member, item, OperationType.B);
	}
	
	
}
