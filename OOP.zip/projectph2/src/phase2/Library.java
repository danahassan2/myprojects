package phase2;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Library {
	private List<Item> items = new ArrayList<>();
	private List<Member> members = new ArrayList<>();
	private List<Operation> operations = new ArrayList<>();
	/**
	 * @param member
	 */
	public void addMember(Member member) { 
		if(member!=null)
		members.add(member);
	}
	/**
	 * @param member
	 */
	public void updateMember(Member member) {
		for ( Member m : members)
			if(m.getId()==member.getId())
			{
				m.setFirstName(member.getFirstName());
				m.setLastName(member.getLastName());
				m.setMobile(member.getMobile());
				m.setMemberType(member.getMemberType());
			}
	}
	/**
	 * @param id
	 */
	public void deleteMember(int id) {
		for(Member m: members)
		if(m.getId()==id)
		members.remove(m);
	}
	/**
	 * @return
	 */
	public List<Member> getMembers() {
		return members; 
	}
	/**
	 * @param id
	 * @return
	 */
	public Member getMember(int id){ 
		for ( Member m: members)
			if(m.getId()==id)
				return m;
		throw new NoSuchElementException("The ID is wrong, please enter your ID again.");
	}
	/**
	 * @param mobile
	 * @return
	 */
	public Member getMember(String mobile) { 
		for ( Member m: members)
			if(m.getMobile()==mobile)
				return m;
		throw new NoSuchElementException("The mobile number you entered is wrong, please enter your mobile number again") ;
	}
	/**
	 * @param item
	 */
	public void addItem(Item item) { 
		if(item!=null)
		items.add(item);
	}
	/**
	 * @param item
	 */
	public void updateItem(Item item) { 
			for ( Item i: items)
			if(i.getItemType()==item.getItemType())
			{
				i.setTitle(item.getTitle());
				i.setItemType(item.getItemType());
				i.setAvailable(item.getIsAvailable());
			}
	}
	/**
	 * @param id
	 * @param isAvailable
	 */
	public void setItemAvailability(String id, boolean isAvailable) { 
		for(Item item: items)
			if(((Book)item).getISBN()==id)
				item.isAvailable();
			else if(((Periodical)item).getIssn()==id)
				item.isAvailable();
	}
	/**
	 * @param id
	 */
	public void deleteItem(String id) { 
		items.remove(id);
	}
	/**
	 * @return
	 */
	public List<Item> getItems(){ 
		return items; 
	}
	/**
	 * @param id
	 * @return
	 */
	public Item getItem(String id) { 
		for(Item item: items)
			if(((Book)item).getISBN()==id)
				return item;
			else if(((Periodical)item).getIssn()==id)
				return item;
		throw new NoSuchElementException("No such item found");
	}
	/**
	 * @param title
	 * @return
	 */
	public Item getItemByTitle(String title) { 
		for ( Item i: items)
			if(i.getTitle()==title)
				return i;
		throw new NoSuchElementException("No such item found");
	}
	/**
	 * @param operation
	 */
	public void addOperation(Operation operation) {
		for(Operation op: operations)
		if(operation.getType()== OperationType.B)
			operations.add(operation);
		else if(operation.getType()== OperationType.R)
			op.setType(OperationType.B);
	}
	/**
	 * @param borrowerID
	 * @return
	 */
	public List<Operation> getLoans(int borrowerID){
			for(Operation op: operations) {	
				if(op.getMember().getId()==borrowerID)
					if(op.getType()==OperationType.B);
			System.out.println(op);}
			throw new NoSuchElementException("No such ID found, please enter your ID again");
	}
	/**
	 * @param formatDate
	 * @param toDate
	 * @return
	 */
	public List<Operation> getLoans(Date formatDate, Date toDate){ 
	List<Operation> loansByDate = new ArrayList<>();
		for(Operation op: operations) {
			if(op.getOperationDate().getDay()>=formatDate.getDay() && op.getOperationDate().getDay()<=formatDate.getDay());
			if(op.getOperationDate().getMonth()>=formatDate.getMonth() && op.getOperationDate().getMonth()<=formatDate.getMonth());
			if(op.getOperationDate().getYear()>=formatDate.getYear() && op.getOperationDate().getYear()<=formatDate.getYear());
			loansByDate.add(op);}
		    if(loansByDate!=null)
		    	return loansByDate;
		    throw new NoSuchElementException("No such loans on that date found");
	}
	public void loadData() {
		
	}
	public void saveData() {
		
	} 
}
