package phase2;



import java.io.File;

import java.io.IOException;

import java.util.Arrays;

import java.util.List;



import com.fasterxml.jackson.databind.ObjectMapper;



public class MembersRepsitory {



    public static List<Member> getStudents() {

    	List<Member> Members = null;

    	ObjectMapper jsonMapper = new ObjectMapper();

		String filePath = "data1/members.json";

		try {

			Member[] MembersArray = jsonMapper.readValue( new File(filePath), Member[].class);

			Members = Arrays.asList(MembersArray);

		} catch (Exception e) {

			System.out.println(e.getMessage());

		}

		

		return Members;

      // students.add(new Student(5, "Ali", "Faleh", "ali@example.com"));

     //   students.add(new Student(10, "Khadija", "Saleh", "khadija@example.com"));

   //   students.add(new Student(15, "Mariam", "Salem", "mariam@example.com"));
	
    }

    

public static void saveStudents(Member[] members) {

		ObjectMapper jsonMapper = new ObjectMapper();

		String filePath = "data/members.json";

		// Write students array to a json file

		try {

			jsonMapper.writeValue(new File(filePath), members);

		} catch (IOException e) {

			e.printStackTrace();

		}

	}

}