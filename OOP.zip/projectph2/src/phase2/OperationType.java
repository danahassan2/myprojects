package phase2;

public enum OperationType {
	B("Borrow"),
	R("Return");
	
	private final String value;

	private OperationType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
}
