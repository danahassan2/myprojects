package phase2;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Member {
	private IntegerProperty id;
	private StringProperty firstName;
	private StringProperty lastName;
	private StringProperty mobile;
	private ObjectProperty<MemberType> memberType;
	
	public Member () {
		this(0,"","","",null);
	}

	public Member(int id, String firstName, String lastName, String mobile, MemberType memberType) {
		this.id = new SimpleIntegerProperty(id);
		this.firstName = new SimpleStringProperty(firstName);
		this.lastName = new SimpleStringProperty(lastName);
		this.mobile = new SimpleStringProperty(mobile);
		this.memberType = new SimpleObjectProperty<MemberType>(memberType);
	}
	
	public IntegerProperty id() { return id; }
	public StringProperty firstName() { return firstName; }
	public StringProperty lastName() { return lastName; }
	public StringProperty mobile() { return mobile; }
	public ObjectProperty<MemberType> memberType() {return memberType;}
	
	public int getId() {
		return this.id.get();
	}
	/**
	 * @param id
	 */
	public void setId(int id) {
		this.id.set(id);
	}
	/**
	 * @return
	 */
	public String getFirstName() {
		return this.firstName.get();
	}
	/**
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName.set(firstName);
	}
	/**
	 * @return
	 */
	public String getLastName() {
		return this.lastName.get();
	}
	/**
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName.set(lastName);
	}
	/**
	 * @return
	 */
	public String getMobile() {
		return this.mobile.get();
	}
	/**
	 * @param mobile
	 */
	public void setMobile(String mobile) {
		this.mobile.set(mobile);
	}
	/**
	 * @return
	 */
	public MemberType getMemberType() {
		return this.memberType.getValue();
	}
	/**
	 * @param type
	 */
	public void setMemberType(MemberType MemberType) {
		this.memberType.set(MemberType);
	}
	@Override
	public String toString() {
		return String.format("Student ID : %d    Name: %s %s   Mobile:%s   MemberType: %s  ",
				getId(), getFirstName(),getLastName(),getMobile(),getMemberType() );
	}
}
