package phase2;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;

public class SearchController {

    @FXML
    private TextField searchTitleField;

    @FXML
    private TextField isbnField;

    @FXML
    private TextField issnField;

}
