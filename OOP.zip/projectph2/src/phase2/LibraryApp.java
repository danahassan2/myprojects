package phase2;
import java.sql.Date;
import java.util.ArrayList;

public class LibraryApp {

	public static void main(String[] args) {
		ArrayList<Author> authors= new ArrayList<Author>();
		Author a1= new Author("J.K", "Rolling");
		authors.add(a1);
		Book book1=new Book("Harry Potter",true,ItemType.B,"AR558",2019,authors);
		System.out.println(book1);
	}

}
