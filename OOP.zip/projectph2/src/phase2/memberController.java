package phase2;

import java.text.NumberFormat;

import javafx.beans.property.Property;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;

public class memberController {

    @FXML
    private DialogPane dailogPane;

    @FXML
    private TextField idField;

    @FXML
    private TextField fnField;

    @FXML
    private TextField lnField;

    @FXML
    private TextField mobileField;

    @FXML
    private TextField memberTypeField;

    @FXML
    private TextField majorField;

   
    public void setMember(Member member) {

    	//Bind the student properties to the UI controls 

    	idField.textProperty().bindBidirectional(member.id(), 

    			NumberFormat.getNumberInstance());

    	fnField.textProperty().bindBidirectional(member.firstName());

    	lnField.textProperty().bindBidirectional(member.lastName());

    	mobileField.textProperty().bindBidirectional(member.mobile());
    	
    	memberTypeField.textProperty().bindBidirectional((Property)member.memberType());
    	
    	majorField.textProperty().bindBidirectional(member.mobile());
    	
    	
    	

    	//Validate before allowing the user to ok

    	Button okButton = (Button)dailogPane.lookupButton(ButtonType.OK);

    	okButton.addEventFilter(

    		ActionEvent.ACTION, event -> {

    			if (!validateFormData()) {

    				// Validation failed -> prevent the dialog to close

    				event.consume();

    			}

    	});

    }
    private boolean validateFormData() {

        if(idField.getText().isEmpty() || idField.getText().equals("0")) {

            showAlert(AlertType.ERROR, "Form Error!",

                    "Please enter the Student Id");

            idField.requestFocus();

            return false;

        }

        

        if(fnField.getText().isEmpty()) {

            showAlert(AlertType.ERROR, "Form Error!",

                    "Please enter your first name");

            fnField.requestFocus();

            return false;

        }

        

        if(lnField.getText().isEmpty()) {

            showAlert(AlertType.ERROR, "Form Error!",

                    "Please enter your last name");

            lnField.requestFocus();

            return false;

        }

        

        if(mobileField.getText().isEmpty() || mobileField.getText().equals("0")) {

            showAlert(AlertType.ERROR, "Form Error!",

                    "Please enter your mobile number");

            mobileField.requestFocus();

            return false;
        }
            
         if(majorField.getText().isEmpty() ) {

                showAlert(AlertType.ERROR, "Form Error!",

                        "Please enter your major");

                mobileField.requestFocus();

                return false;

        }

        

        return true;

    }
    
    private void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.show();
    }    
}
