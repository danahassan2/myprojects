package phase2;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Optional;

import javafx.beans.property.Property;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;

enum DialogMode {ADD, UPDATE}

public class libraryController {

    @FXML
    private TableColumn<Library, Integer> idColumn;

    @FXML
    private TableColumn<Library,String> firstNameColumn;

    @FXML
    private TableColumn<Library,String> lastNameColumn;

    @FXML
    private TableColumn<Library,String> mobileColumn;

    @FXML
    private TableColumn<Member, MemberType> memberTypeColumn;

    @FXML
    private TableColumn<Book,String> titleColumn;

    @FXML
    private TableColumn<Book, String> authorButton;

    @FXML
    private TableColumn<Book,Integer> editionColumn;

    @FXML
    private TableColumn<Periodical,Integer> yearColumn;
    
    @FXML
    private TableView<Item> itemTable;
    @FXML
    private TableView<Member> memberTable;
    private ObservableList<Member> MembersOL = null;
    @FXML
    private Button addButton;

    @FXML
    private Button updateButton;

    @FXML
    private Button deleteButton;

    @FXML
    private Button searchItemButton;

    @FXML
    void handleAdd(ActionEvent event) {
    	handleUpdate(event);
    }

    @FXML
    void handleButton(ActionEvent event) {

		Optional<ButtonType> isConfirmed = showConfirmationDialog("Confim Delete", 

				"Delete Confirmation", "Are you sure you would like to delete the selected member?");

		if (isConfirmed.get() == ButtonType.OK) {

			int selectedIdx = memberTable.getSelectionModel().getSelectedIndex();

			MembersOL.remove(selectedIdx);

		}
    }

    @FXML
    void handleSearchItem(ActionEvent event) {

    }

    @FXML
    void handleUpdate(ActionEvent event) {
    	Member member = null;
    	String dialogTitle ="";
    	DialogMode mode;
    	if (event.getSource().equals(updateButton)) {
    		mode = DialogMode.UPDATE;
    		dialogTitle="Update member";
    		member = memberTable.getSelectionModel().getSelectedItem();
    	}
    	else if (event.getSource().equals(addButton)) {
    		mode = DialogMode.ADD;
    		dialogTitle="Add member";
    		member = new Member();
    	}else return;

    	try {
   
    		FXMLLoader fxmlLoader = new FXMLLoader();
        	fxmlLoader.setLocation(getClass().getResource("Library.fxml"));
        	System.out.println(fxmlLoader.getLocation());
        	DialogPane tripDialogPane = fxmlLoader.load();
			
			libraryController libraryController = fxmlLoader.getController();
			//libraryController.setMember(member);
			Dialog<ButtonType> dialog = new Dialog<>();
			dialog.setDialogPane(tripDialogPane);
			dialog.setTitle(dialogTitle);
			Optional<ButtonType> clickedButton = dialog.showAndWait();
			if (clickedButton.get()==ButtonType.OK) {
				System.out.println("Ok is selected");
				if (mode==DialogMode.ADD)
					MembersOL.add(member);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }

    private Optional<ButtonType> showConfirmationDialog(String title, String headerText, String contentText) {

		Alert alert = new Alert(AlertType.CONFIRMATION);

		alert.setTitle(title);

		alert.setHeaderText(headerText);

		alert.setContentText(contentText);



		return alert.showAndWait();

	}



	private void showInformationDialog(String title, String headerText, String contentText)

	{

		Alert alert = new Alert(AlertType.INFORMATION);

		alert.setTitle(title);

		alert.setHeaderText(headerText);

		alert.setContentText(contentText);

		alert.showAndWait();

	}
  public void initialize() {
	  
  }
}
