package phase2;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Periodical extends Item {
	private String issn;
	private int issue;
	private int year;
	
	/**
	 * @param title
	 * @param isAvailable
	 * @param type
	 * @param issn
	 * @param issue
	 * @param year
	 */
	public Periodical(String title, boolean isAvailable, ItemType type, String issn, int issue, int year) {
		super(title, isAvailable, type);
		this.issn = issn;
		this.issue = issue;
		this.year = year;
	}

	/**
	 * @return
	 */
	public String getIssn() {
		return issn;
	}

	/**
	 * @param issn
	 */
	public void setIssn(String issn) {
		this.issn = issn;
	}

	/**
	 * @return
	 */
	public int getIssue() {
		return issue;
	}

	/**
	 * @param issue
	 */
	public void setIssue(int issue) {
		this.issue = issue;
	}

	/**
	 * @return
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return String.format("%s\t%d\t%s\t%s\t%d\t%d", 
				getTitle(), isAvailable(), getItemType(), issn,issue,year);
	}
	
}
