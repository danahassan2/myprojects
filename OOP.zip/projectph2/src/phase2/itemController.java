package phase2;

import java.text.NumberFormat;

import javafx.beans.property.Property;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class itemController {

    @FXML
    private TextField titleField;

    @FXML
    private ComboBox<Boolean> availableCombo;

    @FXML
    private ComboBox<String> itemTypeField;

  

    public void setItem(Item item) {
    
    	titleField.textProperty().bindBidirectional(item.title());
    	//itemTypeField.valueProperty().bindBidirectional(item.itemType());
    	availableCombo.valueProperty().bindBidirectional(item.isAvailable());
    	
}
}
