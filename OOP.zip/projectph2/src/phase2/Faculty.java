package phase2;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Faculty extends Member {
	private String officePhone;
	private College college;
	/**
	 * @param id of the faculty
	 * @param firstName of the faculty
	 * @param lastName of the faculty
	 * @param mobile number of the faculty
	 * @param type 
	 * @param officePhone of the faculty office
	 * @param college name 
	 */
	public Faculty(int id, String firstName, String lastName, String mobile, MemberType type, String officePhone, College college) {
		super( id, firstName, lastName,mobile, type);
		this.officePhone = officePhone;
		this.college = college;
	}
	/**
	 * @return
	 */
	public String getOfficePhone() {
		return officePhone;
	}
	/**
	 * @param officePhone
	 */
	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}
	/**
	 * @return
	 */
	public College getCollege() {
		return college;
	}
	/**
	 * @param college
	 */
	public void setCollege(College college) {
		this.college = college;
	}

	@Override
	public String toString() {
		return String.format("ID : %d    Name: %s %s   Mobile:%s   MemberType: %s   Office phone: %s\tCollege: %s",
				getId(), getFirstName(), getLastName(), getMobile(), MemberType.F.getValue(), officePhone, college.getName());
	}
	
	
}
