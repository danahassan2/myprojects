package phase2;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public enum ItemType {
	B("Book"),
	P("Periodical");
	
	private final String value;
	/**
	 * @param value
	 */
	private ItemType(String value) {
		this.value = value;
	}
	/**
	 * @return
	 */
	public String getValue() {
		return value;
	}

}
