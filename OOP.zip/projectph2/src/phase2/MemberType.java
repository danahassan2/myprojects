package phase2;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public enum MemberType {
	F("Faculty"),
	S("Student");
	
	private final String value;
	/**
	 * @param value
	 */
	private MemberType(String value) {
		this.value = value;
	}
	/**
	 * @return
	 */
	public String getValue() {
		return value;
	}

}
