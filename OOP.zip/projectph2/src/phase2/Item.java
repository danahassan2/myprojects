package phase2;
/**
 * @author Dana Hassan (201800878) - Maryam Arab (201800792) -Fatima Alsuwaidi (201800403)
 *
 */
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
public class Item {

	private StringProperty title;
	private BooleanProperty isAvailable;
	private ObjectProperty<ItemType> itemType;
	
	public Item() {
		this("",false,null);
	}

	public Item(String title, Boolean isAvailable, ItemType itemType) {
		super();
		this.title = new SimpleStringProperty(title);
		this.isAvailable = new SimpleBooleanProperty(isAvailable);
		this.itemType = new SimpleObjectProperty<ItemType>(itemType);
	}
	
	 public StringProperty title() {return title;}
	 public BooleanProperty isAvailable() {return isAvailable;}
	 public ObjectProperty<ItemType> itemType(){ return itemType;}
	 
		/**
		 * @return title
		 */
		public String getTitle() {
			return this.title.get();
		}
		/**
		 * @param title
		 */
		public void setTitle(String title) {
			this.title.set(title); 
		}
		/**
		 * @return itemType
		 */
		public ItemType getItemType() {
			return this.itemType.getValue();
		}
		/**
		 * @param type
		 */
		public void setItemType(ItemType itemType) {
			this.itemType.setValue(itemType); 
		}
		/**
		 * @return false or true
		 */
		public boolean getIsAvailable() {
			if(itemType.getValue().equals( OperationType.B) )
			  return this.isAvailable.getValue().FALSE;
		    else
				 return this.isAvailable.getValue().TRUE;
		}
		/**
		 * @param isAvailable
		 */
		public void setAvailable(boolean isAvailable) {
			this.isAvailable.setValue(isAvailable);
		}
		@Override
		public String toString() {
			return String.format("Title: %s   Availablility: %s  Item type: %s ", title,isAvailable(),itemType);
		}
		
}

