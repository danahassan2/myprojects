package phase2;
import java.util.ArrayList;
/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Book extends Item {
	private String ISBN;
	private int edition;
	private ArrayList<Author> authors = new ArrayList<Author>();
	/**
	 * @param title of the book
	 * @param isAvailable checking the availability
	 * @param type
	 * @param iSBN the id of the book
	 * @param edition
	 * @param authors
	 */
	public Book(String title, boolean isAvailable, ItemType type, String iSBN, int edition, ArrayList<Author> authors) {
		super(title,isAvailable,type);
		ISBN = iSBN;
		this.edition = edition;
		this.authors = authors;
	}
    /**
     * @return
     */
    public String getISBN() {
		return ISBN;
	}
	/**
	 * @param iSBN
	 */
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	/**
	 * @return
	 */
	public int getEdition() {
		return edition;
	}
	/**
	 * @param edition
	 */
	public void setEdition(int edition) {
		this.edition = edition;
	}
	/**
	 * @return
	 */
	public ArrayList<Author> getAuthors() {
		return authors;
	}
	/**
	 * @param authors
	 */
	public void setAuthors(ArrayList<Author> authors) {
		this.authors = authors;
	}
	/**
	 * @param author
	 */
	public void addAuthor(Author author) {
		authors.add(author);	
	}
	/**
	 * @param lastName
	 */
	public void removeAuthor(String lastName) {
	  authors.remove(lastName);
	}
	
	@Override
	public String toString() {
		return String.format("%s\t%s\t%s\t%s\t%d\t%d", 
				getTitle(), isAvailable() , getItemType(), ISBN, edition, authors);
	}
	
	
}
