package phase2;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public class Student extends Member {
	private String major;
	
	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param mobile
	 * @param type
	 * @param major
	 */
	public Student(int id, String firstName, String lastName, String mobile, MemberType type,String major) {
		super(id,firstName,lastName,mobile,type);
		this.major = major;
	}
	/**
	 * @return
	 */
	public String getMajor() {
		return major;
	}
	/**
	 * @param major
	 */
	public void setMajor(String major) {
		this.major = major;
	}

	@Override
	public String toString() {
		return String.format("Student ID : %d    Name: %s %s   Mobile:%s   MemberType: %s   Major:%s  ",
				getId(), getFirstName(),getLastName(),getMobile(),MemberType.S.getValue(), major );
	}
	
}
