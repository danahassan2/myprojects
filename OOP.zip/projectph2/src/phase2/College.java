package phase2;

/**
 * @author Dana Hassan(201800878) - Maryam Arab(201800792) - Fatima Alsuwaidi(201800403)
 *
 */
public enum College {
	BE("College of Business and Economics"),
	EDU("College of Education"),
	ENG("College of Engineering"),
	HS("College of Health Sciences"),
	LAW("College of Law"),
	MED("College of Medicine"),
	PHA("College of Pharmacy"),
	SIS("College of Sharia and Islamic Studies");
	
	private final String name;
	/**
	 * @param name
	 */
	private College(String name) {
		this.name = name;
	}
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}
}
