package osProject;

import java.util.Scanner;

public class Sort {
	static void sortMat(int[][] data, int row, int col) {
		int size = row * col;
		// Loop to sort the matrix
		// using Bubble Sort
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size - 1; j++) {

				// Condition to check
				// if the Adjacent elements
				if (data[j / col][j % col] > data[(j + 1) / col][(j + 1) % col]) {

					// Swap if previous value is greater
					int temp = data[j / col][j % col];
					data[j / col][j % col] = data[(j + 1) / col][(j + 1) % col];
					data[(j + 1) / col][(j + 1) % col] = temp;
				}
			}
		}
	}

	static void printMat(int[][] mat, int row, int col) {
		
		System.out.println("\nMatrix after sorting: ");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print(mat[i][j] + " ");
			}
			System.out.println();
		}
	}

	// Driver Code
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of rows and columns in first matrix : \n");
        int rows = scanner.nextInt();
        int columns=scanner.nextInt();
        int matrix[][] = new int[rows][columns];
        
        
        System.out.println("\nEnter matrix elements:");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				matrix[i][j] = scanner.nextInt();
			} 
		}
		
		 System.out.println("\nOriginal Martix:");
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < columns; j++) {
	                System.out.print(matrix[i][j] + " ");
	            }
	            System.out.println();
	        }

		// Function call to sort
		sortMat(matrix, rows, columns);

		// Function call to
		// print matrix
		printMat(matrix, rows, columns);
	}
}
