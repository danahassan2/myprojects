package osProject;

import java.util.Scanner;

public class Sum {

	public static void main(String...args) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of rows and columns in matrix : \n");
        int rows = scanner.nextInt();
        int columns=scanner.nextInt();
        int[][] matrix = new int[rows][columns];
        
        //rows and columns in matrix must be same.
        if(rows == columns) {
        
        System.out.println("Enter the elements in matrix : \n");
        for (int i = 0; i < rows; i++) {
               for (int j = 0; j < columns; j++) {
                     matrix[i][j] = scanner.nextInt();
               }
        }

        //Logic to calculate sum of elements above diagonal.
        int sum=0;
        for (int j = 1; j < columns; j++) {
               for (int i=j-1 ; i>=0 ; i--) {
                     sum= sum + matrix[i][j];
               }
               
        }
        
        //Logic to calculate sum of elements below diagonal.
        int sum2=0;
        for (int i = 1; i < rows; i++) {
               for (int j=i-1 ; j>=0 ; j--) {
                     sum2= sum2 + matrix[i][j];
               }
               
        }

       System.out.println("\nMatrix is : ");
        for (int i = 0; i < rows; i++) {
               for (int j = 0; j < columns; j++) {
                     System.out.print(matrix[i][j] + " ");
               }
               System.out.println();
        } 

        System.out.println("sum of elements above diagonal is: "+sum);
        System.out.println("sum of elements below diagonal is: "+sum2);
        
        int max = sum;
        if(max > sum2) {
        	System.out.println("Above diagonal sum is larger");
        } else {
        	System.out.println("Below diagonal sum is larger");
        }
        } else {
        	System.out.println("Error inputs, Rows/Columns must be equal");
        }

 }
}
