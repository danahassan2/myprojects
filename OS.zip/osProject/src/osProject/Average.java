package osProject;

import java.util.Scanner;

public class Average {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of rows and columns in first matrix : \n");
        int rows = scanner.nextInt();
        int columns=scanner.nextInt();
        int[][] matrix = new int[rows][columns];
        
        Scanner scanner2 = new Scanner(System.in);
        System.out.print("\nEnter number of rows and columns in second matrix : \n");
        int rows2 = scanner2.nextInt();
        int columns2=scanner2.nextInt();
        int[][] matrix2 = new int[rows2][columns2];
        
        if (matrix.length == matrix2.length) {
        
        System.out.println("\nEnter the first matrix:");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				matrix[i][j] = scanner.nextInt();
			}
		}


		System.out.println("\nEnter the second matrix:");
		for (int i = 0; i < rows2; i++) {
			for (int j = 0; j < columns2; j++) {
				matrix2[i][j] = scanner2.nextInt();
			}
		}

		// calculate sum of elements of both the arrays...
		// first declare both sum and define to 0.
		int sum1 = 0, sum2 = 0;

		// sum of elements of first matrix
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				sum1 += matrix[i][j];
			}
		}

		// sum of elements of second matrix
		for (int i = 0; i < rows2; i++) {
			for (int j = 0; j < columns2; j++) {
				sum2 += matrix2[i][j];
			}
		}
		double avg1 = sum1 / (rows*columns);
		double avg2 = sum2 / (rows2*columns2);

		System.out.println("First martix sum:"+sum1+" average:"+avg1);
		System.out.println("Second martix sum:"+sum2+" average:"+avg2);
		
		// compare the matrices
		if (avg1 > avg2) {
			System.out.println("\nFirst matrix average is greater than second matrix");
		} else if (avg1 < avg2) {
			System.out.println("\nSecond matrix average is greater than second matrix.");
		} else {
			System.out.println("Both the matrices have equal average.");
		}
        } else {
        	System.out.println("Error, the matrices must be same size");
        }
	}
}
