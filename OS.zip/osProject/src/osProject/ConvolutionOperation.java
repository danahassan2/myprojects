package osProject;

import java.util.Scanner;

public class ConvolutionOperation {
	static int MOD = 998244353;
	// Function to generate a convolution
	// array of two given arrays
	
	
	static void findConvolution(int[][] a, int[][] b) {
		// Stores the size of arrays
		int n = a.length, m = b.length;

		// Stores the final array
		int[] c = new int[(n + m - 1)];

		// Traverse the two given arrays
		for(int i = 0; i < n; ++i) {
			for(int j = 0; j < m; ++j) {

				// Update the convolution array
				c[i + j] += (a[i][i] * b[j][j]) % MOD;
			}
		}

		// Print the convolution array c[]
		for(int k = 0; k < c.length; ++k) {
			c[k] %= MOD;
			System.out.print(c[k] + " ");
		}
	}
	
	public static void main(String[] args) {
		int i, j, k, rowF, rowS, colF, colS;
		int Kernel[][] = new int[10][10];
		int Matrix[][] = new int[10][10];
		
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter Rows and Cols of First Matrix (either 2X2 or 3X3)");
		rowF = scanner.nextInt();
		colF = scanner.nextInt();

		System.out.println("Enter Rows and Cols of Second Matrix (either 8X8 or 16X16)");
		rowS = scanner.nextInt();
		colS = scanner.nextInt();

		System.out.println("Enter Elements of Kernel Matrix");
	
			// Input first matrix from user
			for (i = 0; i < rowF; i++) {
				for (j = 0; j < colF; j++) {
					Kernel[i][j] = scanner.nextInt();
				}
			}
	
			System.out.println("Enter Elements of the Matrix");
	
			// Input second matrix from user
			for (i = 0; i < rowS; i++) {
				for (j = 0; j < colS; j++) {
					Matrix[i][j] = scanner.nextInt();
				}
			}
			
		findConvolution(Kernel, Matrix);

		}
}
