#include <stdio.h>

int main(int argc, char const *argv[]) {
  int input;
  int firstTerm = 0, secondTerm = 1;
  int nextTerm = firstTerm + secondTerm;
  if(argc == 2){
    input = atoi(argv[1]);
  } else {
  printf("Enter number for Fibonacci: ");
  scanf("%d", &input);
  }

  printf("\nFibonacci number sequence: %d, %d, ", firstTerm, secondTerm);
  for (int i = 2; i <= input; i++) {
    if(i!=input){
      printf("%d, " , nextTerm);
      firstTerm = secondTerm;
      secondTerm = nextTerm;
      nextTerm = firstTerm + secondTerm;
    }
    else {
      printf("%d \n" , nextTerm);
    }
  }
  return 0;
}
