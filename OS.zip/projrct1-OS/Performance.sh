#!/bin/bash

#saving the backup time in a variable..
x=$(date +%y%m%d%I%M%S)

function_sub1() {

	#du -m /home | sort -k1 command is to get the home directory usage in MB and reverse order
        #double greater than following the text file name is to save the output in this file and 
	#create it in the same time in one line
	du -m /home | sort -k1 >> Disk_usage.txt

       ########################################################
	
	#below command is to get the architectur+num of cpus+model name+ vendor id only not all the info of cpu
	#and save them all in variables
	architecture=$(lscpu | grep 'Architecture')
	cpus_num=$(lscpu | grep 'CPU(s)')
    	model_name=$(lscpu | grep 'Model name')
    	vendor_id=$(lscpu | grep 'Vendor ID')
    	
    	#Display the info of cpu and save it in cpu_inf.txt file and create it 
	echo "$architecture $cpus_num $model_name $vendor_id" >> cpu_inf.txt

  	########################################################
	
	#saving the kernel output in a file and creating it in one line
  	dmesg -k >> memo-HDMessages_Log.txt

     	########################################################

	#counting the lines in that file and save it in a new file with creating it in one line
	wc -w memo-HDMessages_Log.txt>>Message_Count.txt

        ########################################################

	#creating compressed file and saving the three text files in it
	tar -czf Phase1.tar.gz Disk_usage.txt cpu_inf.txt Message_Count.txt
	
	#getting the backup time of the system
	backuptime=$(date +%I%M%S)
	
	#creating a directory and naming it with the backup time
	mkdir "$backuptime"
	
	#copying the compress file into the directory
	cp Phase1.tar.gz "$backuptime" 
}
function_sub1

function_sub2() {

	#making a directory with the backup time name..
	mkdir "$x"

	#looping through files
	for files in $(ls ~)
	do

	#getting the octal permissions mode from every file
	y=$(stat -c "%a" $files)

	#comparing files permession mode to the one needed 600 = u+rw
	if [ -f "$files" ] && [ "$y" -eq 600 ] ;
	then

	#copying the files and displaying them
	cp $files $x
	echo "$files"

	# changing files mode to read only
	$(chmod 400 "$x/$files")
	fi
	done

}
function_sub2


function_sub3(){

	#saving num of files in a variable..
	files_num=$(ls "$x" | wc -l)
	echo "the number of files in the directory is $files_num"
	echo "End Of Execution.."
}
function_sub3









