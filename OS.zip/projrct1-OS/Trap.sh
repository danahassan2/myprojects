#!/bin/bash

function_sub() {
#ignores the user interrupts and shows the below message
trap 'echo "Whatever you are doing is ignored";' INT #ignore SIGNIT
}
function_sub
