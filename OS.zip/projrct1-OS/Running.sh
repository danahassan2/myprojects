#!/bin/bash

function_sub1() {
	read x 
	#To read  from the user his username
	echo  "**************************************************"
	#Display the username
	echo "$x is currently logged in the linux system"
	echo ""
	#cal is a command that displays the caledner
	echo "The current month calendar $(cal)"
	#date command is to display the system date and time
	echo "The time on the linux system is $(date)"
	echo ""
	#who -b is to display the system boot and the last command is to display the idle time
	echo "$(who -b) and system idle time $(who -u | awk '{print $6,$7}')"
	echo ""
	#pwd command is to show the current working path
	echo "The current working path is $PWD "
	#shell to show the shell type
	echo "The current shell is $SHELL"
	#home to display the home directory
	#du -sk command shows the directory size in KB
	echo "My home directory is $HOME with the directory size in my home = $(du -sk)"
	echo "Describe here briefly the purpose of the Script"
	echo "*************************************************"
}
function_sub1

function_sub2(){
	#below loop is for Running infinitly
	while true
	do
		#Compare if the system time is equal to 11:59PM
		if [ "$(date +%I:%M%p)" = "$(date +11:59PM)" ]
		then 
		#if yes(the system time is qual to 11:59) it will call the below shell scripts
			source Connectivity.sh
			source ControlTraffic.sh
			sleep 600
		#after 10 mins the system will call the below shell scripts
			source FileSystem.sh
			source Performance.sh
		fi #end of if statement
		source Trap.sh
	done #end of loop
}
function_sub2
