#!/bin/bash

function_sub1() {

connec=$(cat < /dev/null > /dev/tcp/8.8.8.8/53; echo $?);
gw=$(netstat -rn | grep '^\(default\|0\.0\.0\.0\)' | awk '{print $2}');

if [ "$connec" -eq 0 ]
then
ping -s 1000 "$gw" -c 10
$(dig qu.edu.qa) >> ~/tmp/PINGRESULTS.txt
else
ping localhost
netstat -r >> ~/tmp/NETINFO.txt
sleep 15
reboot
fi

}
function_sub1
