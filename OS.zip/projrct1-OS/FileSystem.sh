#!/bin/bash
#FileSystem.sh

touch OUTFILE.txt
touch HOLDFILE.txt

#Initialize the file
cat /dev/null > OUTFILE.txt
cat /dev/null > HOLDFILE.txt

function_sub1() {
	#Inserting the date and time of the search and save it to a file 
	echo "Date/Time of Search: $(date +%b) $(date +%d) $(date +%Y) at $(date +%H:%M:%S)" > OUTFILE.txt
}
function_sub1

function_sub2() {

	echo "Searching for Files Larger Than 8Mb starting in /home/HomeDir"
	echo "Please Standby for the Search Results..."
	#Search for files greater than 8MB and save it to HOLDFILE.txt file
	find /home -type f -size +8M > HOLDFILE.txt
	#Find the size of HOLDFILE.txt file
	size=$(wc -c HOLDFILE.txt | awk '{print $1}')

	#See if the file is empty or not
	if [ "$size" -eq 0 ]
	then #if the file is empty
		echo "No files were found that are larger than 8MB"
		echo "exiting..."
	else #if the file is not empty
		#counting the lines in HOLDFILE.txt file
		no_of_lines=$(wc -l < HOLDFILE.txt)
		cat HOLDFILE.txt >> OUTFILE.txt
		echo "Number of files found: $no_of_lines" >> OUTFILE.txt
		echo ""
	fi
}
function_sub2

function_sub3() {
#	Display contents in OUT-FILE file
	cat OUTFILE.txt
	echo "These search results are stored in /home/HomeDir/OUTFILE.txt"
	echo "Search complete...Exiting..."
}
function_sub3

