package a;

import java.util.ArrayList;
import java.util.List;

public class Tree {
	public Node root; // the only data field in Tree
	public ArrayList<Student> list= new ArrayList<Student>();
	public Node find(int key) {
		Node current = root;
		if(current!=null) {
		while (current.iData != key ) {
			if (key < current.iData)
				current = current.leftChild;
			else
				current = current.rightChild;
			if (current == null)
				return null;
		}
		return current;
		}
		else return null;
	}

	public void insert(int id,Student d) {
		Node newNode = new Node(id,d, null, null);
		if (root == null)
			root = newNode;
		else {
			Node current = root;
			Node parent;
			while (true) {
				parent = current;
				if (id < current.iData) { // go left
					current = current.leftChild;
					if (current == null) {
						parent.leftChild = newNode;
						return;
					}
				} else { // go right
					current = current.rightChild;
					if (current == null) {
						parent.rightChild = newNode;
						return;
					}
				}
			}
		}
	}

	public void preorder(Node localroot) {
		if (localroot == null)
			return;
		System.out.print(localroot.dData + "\n");
		preorder(localroot.leftChild);
		preorder(localroot.rightChild);

	}

	public void inorder(Node localroot) {
		if (localroot == null)
			return;
		inorder(localroot.leftChild);
		System.out.print(localroot.dData + "\n");
		inorder(localroot.rightChild);

	}

	public void postorder(Node localroot) {
		if (localroot == null)
			return;
		postorder(localroot.leftChild);
		postorder(localroot.rightChild);
		System.out.print(localroot.iData + "\t");
	}

	public int count() {
		return countNodes(root);
	}

	private int countNodes(Node n) {
		if (n == null)
			return 0;
		else
			return 1 + countNodes(n.leftChild) + countNodes(n.rightChild);
	}

	public void printLeaves() {
		printAllLeaves(root);
	}

	private void printAllLeaves(Node n) {
		if (n != null)
			if (n.leftChild == null && n.rightChild == null)
				n.displayNode();
			else {
				printAllLeaves(n.leftChild);
				printAllLeaves(n.rightChild);
			}
	}

	public boolean delete(int key) {
		Node target = root, parent = root;
		boolean isLeftChild = true;

// ----------- Search for node		
		while (target.iData != key) {
			parent = target;
			if (key < target.iData) {
				isLeftChild = true;
				target = target.leftChild;
			} else {
				isLeftChild = false;
				target = target.rightChild;
			}
			if (target == null)
				return false;
		}

// ----------- 	Case 1: node is leaf
		if (target.leftChild == null && target.rightChild == null) {
			if (target == root)
				root = null;
			else if (isLeftChild)
				parent.leftChild = null;
			else
				parent.rightChild = null;
		}

// ---------- Case 2: node has 1 child
		else if (target.rightChild == null) // if no right child, replace with left subtree
			if (target == root)
				root = target.leftChild;
			else if (isLeftChild)
				parent.leftChild = target.leftChild;
			else
				parent.rightChild = target.leftChild;
		else if (target.leftChild == null)
			if (target == root)
				root = target.rightChild;
			else if (isLeftChild)
				parent.leftChild = target.rightChild;
			else
				parent.rightChild = target.rightChild;

// ---------- Case 3: node has 2 children	
		else {
			Node successor = getSuccessor(target);
			if (target == root)
				root = successor;
			else if (isLeftChild)
				parent.leftChild = successor;
			else
				parent.rightChild = successor;

			successor.leftChild = target.leftChild;
		}
		return true;
	}

	private Node getSuccessor(Node delNode) {
		Node successorParent = delNode;
		Node successor = delNode;
		Node current = delNode.rightChild;
		while (current != null) {
			successorParent = successor;
			successor = current;
			current = current.leftChild;
		}
		if (successor != delNode.rightChild) {
			successorParent.leftChild = successor.rightChild;
			successor.rightChild = delNode.rightChild;
		}
		return successor;
	}

	public int max(Node node) {
		if (node.rightChild != null)
			return max(node.rightChild);
		return node.iData;

	}

	public int depth(int k, Node node) {
		if (find(k) == null) {
			System.out.println("not found");
			return -1;
		}
		if (k == node.iData)
			return 0;
		else if (k < node.iData)
			return 1 + depth(k, node.leftChild);
		else
			return 1 + depth(k, node.rightChild);
	}

	public int countLeaves(Node node) {
		if (node == null)
			return 0;
		if (node.leftChild == null && node.rightChild == null)
			return 1;
		else
			return countLeaves(node.leftChild) + countLeaves(node.rightChild);

	}

	public int treeHeight(Node node) {
		if(node == null)
			return 0;
		int leftHeight = treeHeight(node.leftChild);
		int rightHeight = treeHeight(node.rightChild);
		if(leftHeight > rightHeight)
			return leftHeight + 1;
		else
			return rightHeight + 1 ;
	}

	public boolean isFullTree(Node node) { // full tree is the one where each node has two or zero children
		if(node.leftChild == null && node.rightChild == null)
			return true;
		if(node.leftChild != null && node.rightChild != null)
			return isFullTree(node.leftChild) && isFullTree(node.rightChild);
		
		return false;		
	}
	public ArrayList<Student> getStudentWithGPALess(double gpa) {
		getStudentWithGPALess(root,gpa);
		return list;
	}
	public void getStudentWithGPALess(Node n,double gpa) {
		if(n!=null) {
		if(n.dData.getGPA()<gpa) {
			list.add(n.dData);
		}
		getStudentWithGPALess(n.leftChild,gpa);
		getStudentWithGPALess(n.rightChild,gpa);}
	}
	
}




