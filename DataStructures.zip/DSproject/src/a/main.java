package a;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class main {
	public static void main(String[] args) {
	ArrayList<Student> students = new ArrayList<Student>();
		
		Student ali = new Student(201709879, "ali", "Qatar", 3); 
		Student dana = new Student(201800878, "dana", "Qatar", 3);
		Student amna = new Student(201800312, "amna", "Qatar", 3.5);
		Student s4 = new Student(201988877, "dan","Jordan", 2);
		Student s5 = new Student(201709875, "ali", "Egypt", 1.9); 
		Student s6 = new Student(200100878, "dana", "Mexico", 2.6);
		Student s7 = new Student(200200312, "amna", "Spain", 3.8);
		Student s8 = new Student(201588877, "dan","UK", 2.1);
		students.add(ali);
		students.add(amna);
		students.add(dana);
		students.add(s4);
		students.add(s5);
		students.add(s6);
		students.add(s7);
		students.add(s8);
	
		TreeTable tabletree = new TreeTable();
			
		for(Student s: students) {
			tabletree.insert(s);
		}
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		while(true){

		System.out.println("\n"+"1. Add new student:\n"
						 + "2. Search for a student:\n"
						 + "3. Delete a student:\n"
						 + "4. Display students data: \n"
						 + "5. Display students with less GPA:\n"
						 + "6. Display All students:\n"
						 + "7. Exit"
						 );
		int choice = sc.nextInt();
		  
		if(choice == 1){
		System.out.println("Enter Id:");
		int id = sc.nextInt();
		System.out.println("Enter name: ");
		String name = sc1.nextLine();
		System.out.println("Enter Address: ");
		String address = sc1.nextLine();
		System.out.println("Enter GPA: ");
		double GPA = sc.nextDouble();
		Student student=new Student(id,name,address,GPA);
			tabletree.insert(student);
			}
		else if(choice == 2){
			System.out.println("Enter id to search: ");
			int id = sc.nextInt();
			Student student=tabletree.find(id);
			System.out.println(student);
			}
		else if(choice == 3){
			System.out.println("Enter id to delete: ");
			int id = sc.nextInt();
			Student s=tabletree.find(id);
			if (s==null)
				System.out.println("student is not find");
			if(s!=null) {
			System.out.println(s.toString());
			System.out.println("Are you sure about deleting this student? (y for yes/N for No)");
			String check = sc2.nextLine();
			if(check.equalsIgnoreCase("Y")) {
				boolean istrue=tabletree.remove(id);
				if(istrue)
				System.out.println("student is removed");
			}
			else if(check.equalsIgnoreCase("N")) {
				System.out.println("Cancelled");
				}
			}
			}
		else if(choice == 4){
			System.out.println("Enter year to display: ");
			int year = sc.nextInt();
			tabletree.printStudents(year);
			}
		else if(choice == 5){
			System.out.println("Enter gpa to find less: ");
			double gpa = sc.nextDouble();
			List<Student> list=tabletree.studentWithGPALess(gpa);
			for(var l: list) {
			System.out.println(l);
			}
			}
		else if(choice ==6) {
			tabletree.printAll();
		}
		else if(choice==7) {
			break;
		}
		
	}
		}
	}
