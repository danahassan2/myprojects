package a;



public class Student {
private int id;
private String name;
private String address;
private double GPA;

public Student(int id, String name, String address, double gPA) {
	super();
	this.id = id;
	this.name = name;
	this.address = address;
	GPA = gPA;
}

public int getId() {
	return id;
}

public String getName() {
	return name;
}

public String getAddress() {
	return address;
}

public double getGPA() {
	return GPA;
}

public void setId(int id) {
	this.id = id;
}

public void setName(String name) {
	this.name = name;
}

public void setAddress(String address) {
	this.address = address;
}

public void setGPA(double gPA) {
	GPA = gPA;
}

@Override
public String toString() {
	return String.format("ID : %d , Student Name: %s, Student address : %s , Student GPA: %.2f ",  id,  name,  address, GPA);
}




}
