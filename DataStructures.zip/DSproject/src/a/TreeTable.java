package a;

import java.util.ArrayList;
import java.util.List;

public class TreeTable {
	private Tree[] hashTree;
	private final int size = 20;

	public TreeTable() {
		hashTree = new Tree[size];
		for (int j = 0; j < size; j++)
			hashTree[j] = new Tree();
	}

	public int hashFunc(int year) {
		return year % size;
	}

	public void insert(Student s) {
	
	 if(find(s.getId())!= null) {
	System.out.println("There is a student with this id..try again");
	}	
	else if (find(s.getId())==null) {
		int n = first4digits(s.getId());
		int key = s.getId();
		if ((n > 2000 && n < 2020) && (s.getGPA()>0 && s.getGPA()<=4) && (NumberDigits(s.getId())==9)) {
			int hashVal = hashFunc(n);
			hashTree[hashVal].insert(key, s);
		} else
			System.out.println("Your ID is out of range.. Try Again");
	}
		
	}

	public Student find(int id) {
		int n = first4digits(id);
		int hashVal = hashFunc(n);
		Node key = hashTree[hashVal].find(id);
		if(key!=null) {
		if (key.dData.getId() == id)
			return key.dData;
		
		else
			return null;
		}
		else 
			return null;
	}

	public boolean remove(int id) {
		int n = first4digits(id);
		int hashVal = hashFunc(n);
		// hashTree[hashVal].delete(id);
		if (hashTree[hashVal].delete(id) == true)
			return true;
		return false;
	}

	public void printStudents(int year) {
		// int n= first4digits(id);
		int hashVal = hashFunc(year);
		Tree tree = hashTree[hashVal];
		tree.inorder(tree.root);

	}

	public void printAll() {
		for (int i = 0; i < 20; i++) {
			Tree tree = hashTree[i];
			tree.preorder(tree.root);
		}
	}

	
	 public ArrayList<Student> studentWithGPALess(double gpa) { 
	 ArrayList<Student> list = new ArrayList<Student>();
	 for(int i=0; i<20;i++){ 
	  Tree tree=hashTree[i]; 
	  ArrayList<Student> list1 =tree.getStudentWithGPALess(gpa);
		  list.addAll(list1);
	   } 
	   return list;
	    } 

	 

	public static int first4digits(int n) {
		while (n > 9999) {
			n = n / 10;
		}
		return n;
	}
	public int NumberDigits(int n) {

        int count = 0;

        while(n != 0)
        {
            n /= 10;
            ++count;
        }
   return count;
       
    }
}
