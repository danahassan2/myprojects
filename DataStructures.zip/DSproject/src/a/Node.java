package a;

public class Node {
	public int iData;
	public Student dData;
	public Node leftChild;
	public Node rightChild;

	public Node(int i, Student d,Node l, Node r) {
		this.iData = i;
		this.dData=d;
		this.leftChild = l;
		this.rightChild = r;
	}
	public void displayNode() {
		System.out.printf("{%d,", iData);

	}
	
}