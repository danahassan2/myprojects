--Sara alshafi  2014030347
--sara alrowali 201306979
--Dana hassan   201800878

CREATE TABLE Allowance (
  Name varchar2(20) NOT NULL,
  Description varchar2(20) NOT NULL,
  Amount number(10) NOT NULL
) ;


CREATE TABLE Car (
  Car_ID number(10) NOT NULL,
  Make varchar2(10) NOT NULL,
  Model varchar(10) NOT NULL,
  Next_mnt_Date date NOT NULL,
  Emp_ID number(10) NOT NULL
) ;


 CREATE TABLE Department (
  Department_Name varchar2(20) NOT NULL,
  Description varchar(20) NOT NULL,
  Total_Employees number(30) NOT NULL
) ;

---- --------------------------------------------------------
----
---- Table structure for table `Department_Projects`
----

CREATE TABLE Department_Projects (
  Department_Name varchar2(15) NOT NULL,
  Project_ID number(10) NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL
);

---- --------------------------------------------------------
----
---- Table structure for table `Employees`
----

CREATE TABLE Employees (
  Emp_ID number(10) NOT NULL,
  Employee_Name varchar2(20) NOT NULL,
  Salary number(10) NOT NULL,
  Phone_number number(8) NOT NULL,
  DateofBirth date NOT NULL,
  Position varchar2(10) NOT NULL,
  Department_Name varchar2(10) NOT NULL,
   Grade varchar2(2) NOT NULL
) ;
INSERT INTO Employees VALUES ( 1233,'mark', 40000 ,23456781,To_Date('1996-04-23','YYYY/mm/dd'),'admin', 'manager' ,'B');
  





----------------------------------------------------------------

----
---- Table structure for table `Emp_Allowance`
----

CREATE TABLE Emp_Allowance (
  Emp_ID number(10) NOT NULL,
  Allowance_Name varchar2(10) NOT NULL
) ;

---- --------------------------------------------------------

----
---- Table structure for table `Grade`
----

CREATE TABLE Grade (
  Grade_Name varchar2(1) NOT NULL,
  Min_Salary number(10) NOT NULL,
  Max_Salary number(10) NOT NULL
) ;

---- --------------------------------------------------------

----
---- Table structure for table `HR_Employee`
----

CREATE TABLE HR_Employee (
  Emp_ID number(10) NOT NULL,
  username varchar2(10) NOT NULL,
  password varchar2(10) NOT NULL
) ;

INSERT INTO HR_Employee (Emp_ID, username, password) VALUES
(1, 'max', 'max123');

INSERT INTO HR_Employee (Emp_ID, username, password) VALUES
(2, 'john', 'johndoe');

---- --------------------------------------------------------

----
---- Table structure for table `Project`
----

CREATE TABLE Project (
  Project_ID number(5) NOT NULL,
  Name varchar2(10) NOT NULL,
  Description varchar2(10) NOT NULL
);

ALTER TABLE project MODIFY description varchar2(70);

INSERT INTO project values (1,'bulding','small bulding');
INSERT INTO project values (3,'making','write java code');
INSERT INTO project values (9,'bulding','small bulding');
INSERT INTO project values (10,'bulding','small bulding');
INSERT INTO project values (11,'bulding','small bulding');

SELECT * FROM   project  WHERE PROJECT_ID = 1;
---- --------------------------------------------------------

----
---- Table structure for table `Transaction`
----

CREATE TABLE Transaction (
  Transaction_ID number(10) NOT NULL,
  DateTime varchar2(10) NOT NULL,
  Username varchar2(10) NOT NULL
) ;

---- --------------------------------------------------------


----
---- Indexes for table `Allowance`
----
ALTER TABLE Allowance
  ADD PRIMARY KEY (Name);

----
---- Indexes for table `Car`
----
ALTER TABLE Car
  ADD PRIMARY KEY (Car_ID);

----
---- Indexes for table `Department`
----
ALTER TABLE Department
  ADD PRIMARY KEY (Department_Name);

----
---- Indexes for table `Employees`
----
ALTER TABLE Employees
  ADD PRIMARY KEY (Emp_ID);

----
---- Indexes for table `Grade`
----
ALTER TABLE Grade
  ADD PRIMARY KEY (Grade_Name);

----
---- Indexes for table `HR_Employee`
----
ALTER TABLE HR_Employee
  ADD PRIMARY KEY (Emp_ID);
  

----
---- Indexes for table `Project`
----
ALTER TABLE Project
  ADD PRIMARY KEY (Project_ID);

----
---- Indexes for table `Transaction`
----
ALTER TABLE Transaction
  ADD PRIMARY KEY (Transaction_ID);

CREATE or REPLACE TRIGGER newtrigger
AFTER INSERT ON EMPLOYEES
FOR EACH ROW
ENABLE
DECLARE 
BEGIN
dbms_output.put_line('TRANSACTION DONE');
INSERT INTO Transaction(DATETIME,USERNAME) VALUES (SYSDATE,USER);
END;

INSERT INTO CAR VALUES (123,'Latest','Ferrari',To_Date('2020-04-04','YYYY/mm/dd'),776);
INSERT INTO CAR VALUES (993,'Latest','KYA',To_Date('2020-04-04','YYYY/mm/dd'),786);
INSERT INTO CAR VALUES (783,'Latest','NISSAN',To_Date('2020-04-04','YYYY/mm/dd'),786);
INSERT INTO CAR VALUES (888,'Latest','NISSAN',To_Date('2020-04-04','YYYY/mm/dd'),786);
INSERT INTO CAR VALUES (555,'Latest','NISSAN',To_Date('2020-04-04','YYYY/mm/dd'),786);

COMMIT;