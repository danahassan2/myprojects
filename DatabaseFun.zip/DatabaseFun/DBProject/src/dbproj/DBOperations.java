//Sara alshafi 2014030347
//Sara alrowali 201306979 
//Dana hassan 201800878

package dbproj;

import java.io.*;
import java.sql.*;

public class DBOperations {
	String dburl="jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa"; 
	String username="sa1403047";
	String password="sa1403047";

	Connection conn;
	Statement stmt;

	public DBOperations() {
		try {
			conn= DriverManager.getConnection(dburl,username, password);
			stmt=conn.createStatement();
			System.out.println("Connected");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}

	public Boolean addEmployee(String empID, String name, String salary, String phoneNo, String DOB, String position, String dept) {
		
		String grade = "D";
		int sal = Integer.parseInt(salary);
		if(sal<2000)
			grade ="A";
		else if(sal>=2000 && sal<50000)
			grade = "B";
		else if(sal>=50000)
			grade = "C";
		try {
			stmt.executeUpdate("INSERT INTO Employees" + " VALUES ("+empID+",'"+name+"',"+salary+",'"+phoneNo+"',TO_DATE('"+DOB+"','YYYY/mm/dd'),'"+position+"','"+dept+"','"+grade+"')");
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}	
	}

	public Boolean removeEmployee(String empID) {
		try {
			stmt.executeUpdate("DELETE FROM Employees WHERE Emp_ID="+Integer.parseInt(empID)+"");
			System.out.println("Employee Removed"); 
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Boolean updateSalary(String empID, String salary) {
		try {
			String grade = "D";
			int sal = Integer.parseInt(salary);
			if(sal<2000)
				grade ="A";
			else if(sal>=2000 && sal<50000)
				grade = "B";
			else if(sal>=50000)
				grade = "C";
			
			stmt.executeUpdate("UPDATE Employees" + 
					" SET Salary=" + Integer.parseInt(salary) + ", Grade ='"+ grade +
					" ' WHERE Emp_ID="+Integer.parseInt(empID)+"");
			System.out.println("Salary Updated"); 
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public Boolean HRLogin(String user, String pass) {
		ResultSet rs;
		int c=0;
		try {
			rs = stmt.executeQuery("select * from HR_Employee where username='"+user+"' and password='"+pass+"'");
			while(rs.next()) {
				c++;
			}
			if(c>0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	public void displayEmployees() {
		
		ResultSet rs;
		try {
			rs = stmt.executeQuery("select * from Employees");
			while(rs.next())  
				System.out.println("Employee"); 
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		 
	}

	public String searchProject(String projectID) {
		ResultSet rs;
		String name = null, description = null;
		try {
			rs=stmt.executeQuery("SELECT * FROM Project where Project_ID="+Integer.parseInt(projectID));
			while(rs.next()) {
				name = rs.getString("NAME");
				description = rs.getString("DESCRIPTION");
				
			}
			return "Project name: " +name+"\n, Description: "+description;
		} catch (SQLException e) {
			e.printStackTrace();
			return "Project not found";
		}
	}
	
	public void printReports() throws IOException {
		
		
		File f1 = new File("empHistory.txt");
		FileWriter fstream1 = new FileWriter(f1);
		BufferedWriter out1 = new BufferedWriter(fstream1);

		File f2 = new File("CARHISTORY.txt");
		FileWriter fstream2 = new FileWriter(f2);
		BufferedWriter out2 = new BufferedWriter(fstream2);

		File f3 = new File("projectHistory.txt");
		FileWriter fstream3 = new FileWriter(f3);
		BufferedWriter out3 = new BufferedWriter(fstream3);

		ResultSet rs1,rs2,rs3;
		try {
			rs1 = stmt.executeQuery("SELECT EMPLOYEE_NAME, DEPARTMENT_NAME, POSITION FROM EMPLOYEES");
			
			
			
			
			while (rs1.next()) {
				out1.write(rs1.getString(1)+"\t"+rs1.getString(2)+"\t"+rs1.getString(3)+"\n");
			}
			rs2 = stmt.executeQuery("SELECT EMPLOYEES.EMPLOYEE_NAME,CAR.MODEL FROM EMPLOYEES INNER JOIN CAR ON CAR.EMP_ID=EMPLOYEES.EMP_ID");
			while (rs2.next()) {
				out2.write(rs2.getString(1)+"\t"+rs2.getString(2)+"\n");
			}
			rs3 = stmt.executeQuery("SELECT NAME,DESCRIPTION FROM PROJECT");
			while(rs3.next()) {
				out3.write(rs3.getString(1)+"\t"+rs3.getString(2)+"\n");
			}
			out1.close();
			out2.close();
			out3.close();
			System.out.println("Reports saved");
		

		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}


}

