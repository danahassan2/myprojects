//Sara alshafi 2014030347
//Sara alrowali 201306979 
//Dana hassan 201800878

package dbproj;


public class App {
	
	private String currentUser;

	public static void main(String[] args) {
		Login l = new Login();
		l.setVisible(true);
	}

	public String getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(String currentUser) {
		this.currentUser = currentUser;
	}
}
