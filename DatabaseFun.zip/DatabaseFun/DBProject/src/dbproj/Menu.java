//Sara alshafi 2014030347
//Sara alrowali 201306979 
//Dana hassan 201800878

package dbproj;

import javax.swing.*;

import dbproj.DBOperations;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;

public class Menu extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Menu() {
		getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		setSize(450,300);
		setResizable(false);
		
		JButton btnNewButton = new JButton("Add Employee ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addEmployee a = new addEmployee();
				a.setVisible(true);
				
			}
		});
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update Salary");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateSalary u = new updateSalary();
				u.setVisible(true);
			}
		});
		getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Remove Employeee");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removeEmployee r=new removeEmployee();
				r.setVisible(true);
			}
		});
		getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Search By Project No");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchProject s=new searchProject();
				s.setVisible(true);
			}
		});
		getContentPane().add(btnNewButton_3);
	
		JButton btnNewButton_4 = new JButton("Reports");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBOperations db = new DBOperations();
				try {
					db.printReports();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			

			}
		});
		getContentPane().add(btnNewButton_4);
		
		
		
	}

}
