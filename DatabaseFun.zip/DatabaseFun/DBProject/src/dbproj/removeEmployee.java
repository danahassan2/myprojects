//Sara alshafi 2014030347
//Sara alrowali 201306979 
//Dana hassan 201800878

package dbproj;

import javax.swing.*;

import dbproj.DBOperations;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class removeEmployee extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField;
	public removeEmployee() {
		getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		setSize(450,300);
		setResizable(false);
		
		JLabel lblNewLabel = new JLabel("Employee ID");
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		getContentPane().add(textField);
		textField.setColumns(10);
		JButton btnNewButton = new JButton("Remove Employee");
		getContentPane().add(btnNewButton);
		JLabel lblNewLabel_1 = new JLabel("");
		getContentPane().add(lblNewLabel_1);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBOperations db=new DBOperations();
				Boolean check = db.removeEmployee(textField.getText());
				if(check)
					lblNewLabel_1.setText("Employee Removed");
				else
					lblNewLabel_1.setText("Employee ID does not exist");
			}
		});
		
	}

}
