//Sara alshafi 2014030347
//Sara alrowali 201306979 
//Dana hassan 201800878

package dbproj;

import javax.swing.*;

import dbproj.DBOperations;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField;
	private JPasswordField passwordField;
	private Boolean loginSuccessfull;
	public Login() {
		getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		setSize(450,300);
		setResizable(false);
		
		JLabel lblNewLabel = new JLabel("Username");
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		getContentPane().add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(10);
		getContentPane().add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("");
		getContentPane().add(lblNewLabel_2);
		
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				DBOperations db=new DBOperations();
				loginSuccessfull = db.HRLogin(textField.getText(),passwordField.getText());
				if(loginSuccessfull) {
					Menu m=new Menu();
					m.setVisible(true);
					setVisible(false);
				}
				else
					lblNewLabel_2.setText("Username or password is incorrect");
				
			}
		});
	}

}
